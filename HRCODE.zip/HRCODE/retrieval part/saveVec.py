import gensim
from nltk.tokenize import word_tokenize
import numpy as np
import json
import re
import datetime

def split_identifier(token):
    if len(token) > 3:
        token = re.sub(r'[^A-Za-z0-9\s]', ' ', token)
        token = re.sub(r'[a-z][A-Z]', lambda x: x.group()[0] + ' ' + x.group()[1], token)
        token = re.sub(r'[A-Z]{2}[a-z]]', lambda x: x.group()[0] + ' ' + x.group()[1], token)
    return token.lower().split()

def get_word_vector(wordSeq):
    splitWord = split_identifier(wordSeq)
    wordVec = np.zeros((1,300))
    for word in splitWord:
        try:
            word_vector = model.get_vector(word).copy()
        except:
            word_vector = model.get_vector('unknow').copy()
            if word not in dic:
                dic[word] = 1
            else:
                dic[word] = dic[word] + 1
        wordVec = word_vector + wordVec
    return wordVec


def get_sentence_vector(seg_sentence_word):
    sentence_vector = None
    for word in seg_sentence_word:
        word_vector = get_word_vector(word)
        if sentence_vector is not None:
            sentence_vector += word_vector
        else:
            sentence_vector = word_vector

    sentence_vector = sentence_vector / len(seg_sentence_word)

    return sentence_vector


def cos_sim(vector_a, vector_b):
    vector_a = np.mat(vector_a)
    vector_b = np.mat(vector_b)
    num = float(vector_a * vector_b.T)
    denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
    cos = num / denom
    sim = 0.5 + 0.5 * cos
    return sim


def calAllSim(annofile, actionFile):
    #将所有的数据转化为向量（NL）
    with open(annofile, "r", encoding='utf-8') as f:
        allvector = np.zeros((1, 300))
        for line in f.readlines():
            seg_sentence = line.replace("\t", "").replace("\n", "")
            seg_sentence_word = split_identifier(seg_sentence)
            eachLineVector = get_sentence_vector(seg_sentence_word)
            allvector = np.row_stack((allvector, eachLineVector))

        print('------------the nl train data sim score over------------')
        allvector = np.delete(allvector, 0, 0)
        np.save('a.npy', allvector)
        print(allvector.shape)

    # 将所有的数据转化为向量（Action）
    with open(actionFile, "r", encoding='utf-8') as f:
        allvector1 = np.zeros((1, 300))
        for line in f.readlines():
            seg_sentence = line.replace("\t", "").replace("\n", "")
            seg_sentence_word = split_identifier(seg_sentence)
            eachLineVector = get_sentence_vector(seg_sentence_word)
            allvector1 = np.row_stack((allvector1, eachLineVector))

        print('------------the action train data sim score over------------')
        allvector1 = np.delete(allvector1, 0, 0)
        np.save('b.npy', allvector1)
        print(allvector1.shape)

def cal_ref(a,b):
    allvector= np.load(a)
    allvector1= np.load(b)
    #weight of the NL
    allvector= allvector*0.8 + allvector1*0.2

    allTrainSimScore = np.zeros((16000, 16000))
    allValSimScore = np.zeros((16000, 1000))
    allTestSimScore = np.zeros((16000, 1805))

    # for train
    for i in range(16000):
        for j in range(i+1, 16000):
            allTrainSimScore[i][j] = cos_sim(allvector[i], allvector[j])
    rowMax = np.argmax(allTrainSimScore, axis=1)
    TraincloMax = np.argmax(allTrainSimScore, axis=0)
    MaxScoreP = np.max(np.row_stack((rowMax, TraincloMax)), axis=0)
    print(len(MaxScoreP), MaxScoreP.shape)
    print('------------ train score data over------------')

    # for val
    for i in range(16000):
        for j in range(16000, 17000):
            x = j - 16000
            allValSimScore[i][x] = cos_sim(allvector[i], allvector[j])
    ValcloMax = np.argmax(allValSimScore, axis=0)
    print(len(ValcloMax), ValcloMax.shape)
    print('------------ Val score data over------------')

    # for test
    for i in range(16000):
        for j in range(17000, len(allvector)):
            z = j - 17000
            allTestSimScore[i][z] = cos_sim(allvector[i], allvector[j])
    TestcloMax = np.argmax(allTestSimScore, axis=0)
    print(len(TestcloMax), TestcloMax.shape)
    print('------------ test score data over------------')

    return MaxScoreP, ValcloMax, TestcloMax

#生成
def getTrainFile(fileanno, filecode, MaxScoreP, ValcloMax, TestcloMax):
    print_example = []
    with open(fileanno, "r", encoding='utf-8') as fa:
        annofline = fa.readlines()
    with open(filecode, "r", encoding='utf-8') as fc:
        codefline = fc.readlines()

    for i in range(len(annofline)):
        if i < 16000:
            code = codefline[i].replace("\n", "")
            nl = annofline[MaxScoreP[i]].replace("\n", "") + '<nlSep>' + annofline[i].replace("\n", "") + '<codeSep>' +  codefline[MaxScoreP[i]].replace("\n", "")

        elif 16000 <= i < 17000:
            t = i - 16000
            code = codefline[i].replace("\n", "")
            nl =  annofline[ValcloMax[t]].replace("\n", "") + '<nlSep>' + annofline[i].replace("\n", "") + '<codeSep>' + codefline[ValcloMax[t]].replace("\n", "")

        else:
            t = i - 17000
            code = codefline[i].replace("\n", "")
            nl = annofline[TestcloMax[t]].replace("\n", "") + '<nlSep>' +  annofline[i].replace("\n", "") + '<codeSep>' +  codefline[TestcloMax[t]].replace("\n", "")

        print_example.append({
            'code': code,
            'nl': nl
        })

    return print_example


def writefile(example):
    trainFile = 'train.json'
    validFile = 'valid.json'
    testFile = 'test.json'
    trainfile = open(trainFile, 'a+')
    valfile = open(validFile, 'a+')
    testfile = open(testFile, 'a+')
    for i in range(len(example)):
        if i < 16000:
            trainfile.writelines(json.dumps(example[i]) + '\n')
        elif 16000 <= i < 17000:
            valfile.writelines(json.dumps(example[i]) + '\n')
        else:
            testfile.writelines(json.dumps(example[i]) + '\n')


if __name__ == "__main__":
    dic = {}
    print('------------Loading model start------------')
    model = gensim.models.KeyedVectors.load_word2vec_format('wiki.en.vec')
    print('------------Loading model over------------')
    annofile = 'all.anno'
    codefile = 'all.code'
    actionFile = 'ActionFile.json'

    t1 = datetime.datetime.now()
    calAllSim(annofile, actionFile)
    a = 'a.npy'
    b = 'b.npy'
    MaxScoreP, ValcloMax, TestcloMax = cal_ref(a,b)
    t2 = datetime.datetime.now()
    endtime = t2-t1
    print('time spend',endtime)

    example = getTrainFile(annofile, codefile, MaxScoreP, ValcloMax, TestcloMax)
    writefile(example)

    t3 = datetime.datetime.now()
    endtime1 = t3 - t2
    print('time spend', endtime1)

    print(MaxScoreP, ValcloMax, TestcloMax)
    print(len(dic))

