#!/bin/bash

test_file="F://dajang//tranx//data//django//test.bin"
load_model="F://dajang//tranx//saved_models//django//model.sup.django.lstm.hidden256.embed128.action128.field64.type64.dropout0.3.lr0.001.lr_decay0.5.beam_size5.vocab.freq15.bin.train.bin.glorot.par_state_w_field_embed.seed0.iter60800.bin"
seed=${1:-0}
vocab="vocab.freq15.bin"
train_file="train.bin"
dev_file="dev.bin"
dropout=0.3
hidden_size=256
embed_size=128
action_embed_size=128
field_embed_size=64
type_embed_size=64
ptrnet_hidden_dim=32
lr=0.001
lr_decay=0.5
beam_size=5
lstm='lstm'  # lstm

python F://dajang//tranx//exp.py \
	--cuda \
    --mode test \
    --load_model ${load_model} \
    --beam_size 5 \
    --vocab F://dajang//tranx//data//django//${vocab} \
    --test_file ${test_file} \
    --save_decode_to F://dajang//tranx//scripts//django//decodes//$(basename $1).decode \
    --decode_max_time_step 100 \


