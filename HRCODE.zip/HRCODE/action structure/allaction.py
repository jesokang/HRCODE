# coding=utf-8
from __future__ import print_function
import re
import ast
import codecs
import json
from asdl.lang.py.py_asdl_helper import python_ast_to_asdl_ast, asdl_ast_to_python_ast
from asdl.lang.py.py_transition_system import PythonTransitionSystem
from asdl.hypothesis import *

from components.action_info import ActionInfo

p_elif = re.compile(r'^elif\s?')
p_else = re.compile(r'^else\s?')
p_try = re.compile(r'^try\s?')
p_except = re.compile(r'^except\s?')
p_finally = re.compile(r'^finally\s?')
p_decorator = re.compile(r'^@.*')

QUOTED_STRING_RE = re.compile(r"(?P<quote>['\"])(?P<string>.*?)(?<!\\)(?P=quote)")

def get_action_infos(src_query, tgt_actions, force_copy=False):
    action_infos = []
    hyp = Hypothesis()
    for t, action in enumerate(tgt_actions):
        action_info = ActionInfo(action)
        action_info.t = t
        if hyp.frontier_node:
            action_info.parent_t = hyp.frontier_node.created_time
            action_info.frontier_prod = hyp.frontier_node.production
            action_info.frontier_field = hyp.frontier_field.field

        if isinstance(action, GenTokenAction):
            try:
                tok_src_idx = src_query.index(str(action.token))
                action_info.copy_from_src = True
                action_info.src_token_position = tok_src_idx
            except ValueError:
                if force_copy: raise ValueError('cannot copy primitive token %s from source' % action.token)

        hyp.apply_action(action)
        action_infos.append(action_info)

    return action_infos


class Django(object):
    @staticmethod
    def canonicalize_code(code):
        if p_elif.match(code):
            code = 'if True: pass\n' + code
        if p_else.match(code):
            code = 'if True: pass\n' + code
        if p_try.match(code):
            code = code + 'pass\nexcept: pass'
        elif p_except.match(code):
            code = 'try: pass\n' + code
        elif p_finally.match(code):
            code = 'try: pass\n' + code
        if p_decorator.match(code):
            code = code + '\ndef dummy(): pass'
        if code[-1] == ':':
            code = code + 'pass'
        return code


    @staticmethod
    def canonicalize_example(code):
        canonical_code = Django.canonicalize_code(code)
        return canonical_code

    @staticmethod
    def parse_django_dataset(annot_file, code_file, asdl_file_path, max_query_len=70, vocab_freq_cutoff=10):
        asdl_text = open(asdl_file_path).read()
        grammar = ASDLGrammar.from_text(asdl_text)
        transition_system = PythonTransitionSystem(grammar)
        loaded_examples = []
        for idx, (src_query, tgt_code) in enumerate(
                zip(codecs.open(annot_file, 'r', 'utf-8'), codecs.open(code_file, 'r', 'utf-8'))):
            src_query = src_query.strip()
            tgt_code = tgt_code.strip()
            tgt_canonical_code = Django.canonicalize_example(tgt_code)
            # print(tgt_canonical_code)
            python_ast = ast.parse(tgt_canonical_code)
            tgt_ast = python_ast_to_asdl_ast(python_ast, grammar)
            tgt_actions = transition_system.get_actions(tgt_ast)
            loaded_examples.append(tgt_actions)

        return loaded_examples
    @staticmethod
    def generate_django_train_dataset():
        vocab_freq_cutoff = 8
        annot_file = 'data/django/all.anno'
        code_file = 'data/django/all.code'
        save_file = 'data/django/ActionFile.json'
        example_action = Django.parse_django_dataset(annot_file, code_file,
                                                                'asdl/lang/py/py_asdl.36.txt',
                                                                vocab_freq_cutoff=vocab_freq_cutoff)
        with open(save_file, 'a+') as sf:
            for i in range(len(example_action)):
                if i<16000:
                    sf.writelines(json.dumps(str(example_action[i])) + '\n')



if __name__ == '__main__':
    Django.generate_django_train_dataset()