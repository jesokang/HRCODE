# HRCODE

This model can be divided into three parts: Action structure, Retrieval part, Code generation

## Action structure
This part mainly uses the TRANX model to generate the intermediate framework ACTION.

1. **python dataset.py** gets preprocessed model training and test data
2. **bash train.sh** to get the training model
3. **python allaction.py** gets the ACTION of the training data.
4. **bash test.sh** gets the ACTION of the trained model to generate test data.

We reproduced the TRANX model, and found that the accuracy was only about 0.67, which would limit our ability to obtain accurate ACTION structure, which would lead to the accuracy of the overall retrieved samples.


## Retrieval part

**python saveVec.py.py** to get the data retrieved
The line 88 in saveVec.py is weight of NL and the action structure.

Then, we will produce the train.json,valid.json and test.json.

## Code generation
1. **bash prepareDj.sh** gets preprocessed model training and test data.
2. **bash runDj.sh** to get the each epoch model and output file.
3. **bash evalDj.sh** gets the final code.

## Attention
Please pay attention to modify the location of the data file.


## Reference

```
@inproceedings{yin18emnlpdemo,
    title = {{TRANX}: A Transition-based Neural Abstract Syntax Parser for Semantic Parsing and Code Generation},
    author = {Pengcheng Yin and Graham Neubig},
    booktitle = {Conference on Empirical Methods in Natural Language Processing (EMNLP) Demo Track},
    year = {2018}
}

@inproceedings{AhmadCRC21,
  author    = {Wasi Uddin Ahmad and
               Saikat Chakraborty and
               Baishakhi Ray and
               Kai{-}Wei Chang},
  booktitle = {Proceedings of the 2021 Conference of the North American Chapter of
               the Association for Computational Linguistics: Human Language Technologies,
               {NAACL-HLT} 2021, Online, June 6-11, 2021},
  pages     = {2655--2668},
  publisher = {Association for Computational Linguistics},
  year      = {2021},
}
```