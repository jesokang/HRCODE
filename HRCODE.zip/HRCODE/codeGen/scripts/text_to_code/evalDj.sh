#!/usr/bin/env bash

export PYTHONIOENCODING=utf-8;

while getopts ":h" option; do
    case $option in
        h) # display help
            echo
            echo "Syntax: bash run.sh GPU_ID"
            echo
            exit;;
    esac
done




function generate () {


for num in {1..10}
do
FILE_PREF=/Users/joeykang/Desktop/out/forGraph/output$num
cat $FILE_PREF | grep "^H" |sort -V |cut -f 3- | sed 's/\[${TARGET}\]//g' > $FILE_PREF.hyp;
done



}


function eval () {
python /Users/joeykang/Desktop/out/forGraph/BlueAndAcc.py
}


generate
eval
