import ast
import astor
import re
from string import punctuation
from nltk.translate.bleu_score import sentence_bleu, corpus_bleu, SmoothingFunction
import codecs

# for acc
p_elif = re.compile(r'^elif\s?')
p_else = re.compile(r'^else\s?')
p_try = re.compile(r'^try\s?')
p_except = re.compile(r'^except\s?')
p_finally = re.compile(r'^finally\s?')
p_decorator = re.compile(r'^@.*')


def hyp_correct(self, hyp, example):
    return self.compare_ast(hyp.tree, example.tgt_ast)


def canonicalize_code(code):
    if p_elif.match(code):
        code = 'if True: pass\n' + code
    if p_else.match(code):
        code = 'if True: pass\n' + code
    if p_try.match(code):
        code = code + 'pass\nexcept: pass'
    elif p_except.match(code):
        code = 'try: pass\n' + code
    elif p_finally.match(code):
        code = 'try: pass\n' + code
    if p_decorator.match(code):
        code = code + '\ndef dummy(): pass'
    if code[-1] == ':':
        code = code + 'pass'

    return code


def canonicalize_example(code):
    canonical_code = canonicalize_code(code)
    ast_tree = ast.parse(canonical_code)
    canonical_code = astor.to_source(ast_tree)

    return canonical_code


# for bleu
def tokenize_for_bleu_eval(code):
    code = re.sub(r'([^A-Za-z0-9_])', r' \1 ', code)
    code = re.sub(r'([a-z])([A-Z])', r'\1 \2', code)
    code = re.sub(r'\s+', ' ', code)
    code = code.replace('"', '`')
    code = code.replace('\'', '`')
    tokens = [t for t in code.split(' ') if t]

    return tokens


def strip_punctuation(s):
    return ''.join(c for c in s if c not in punctuation)


def process_class_names(instance):
    try:
        words = instance
        words = words[:10]
        clss = ''
        start = words.index('class')
        end = words.index('(')
        clss = words[start + 1]
        for i in range(start + 2, end):
            clss = clss + ' ' + words[i]
        original_clss = clss
        clss = strip_punctuation(clss)
        clss = " ".join(clss.split())
        words = clss.split(' ')
        clss = ''
        for word in words:
            if word[0].isupper():
                clss = clss + ' ' + word
            else:
                clss = clss + word
        clss = clss.strip()
        instance = " ".join(instance).replace(original_clss, clss, 1).split(" ")
    except:
        pass
    return instance


# ACC function
def cal_acc(testFile, resultFile):
    acc = 0
    for idx, (tgt_code, re_code) in enumerate(
            zip(codecs.open(testFile, 'r', 'utf-8'), codecs.open(resultFile, 'r', 'utf-8'))):
        # print(idx, tgt_code)
        # for test
        tgt_code = tgt_code.strip()
        tgt_canonical_code = canonicalize_example(tgt_code)
        tgt_ast = ast.dump(ast.parse(tgt_canonical_code))
        # for result
        re_code = re_code.strip()
        try:
            re_canonical_code = canonicalize_example(re_code)
            re_ast = ast.parse(re_canonical_code)
            re_ast = ast.dump(re_ast)

        except:
            re_ast = 'error'

        if tgt_ast == re_ast:
            acc = acc + 1
        # else:
        #     print("idx:", idx + 1)
        #     print("tgt_code： ", tgt_code)
        #     print("gen_code： ", re_code)
        #     print('\n')

        # print('re_ast', re_ast)
    Acc = acc / 1805
    # print(Acc)
    return Acc


# blue function
def cal_bleu(testFile, resultFile):
    cum_bleu = 0.0
    sm = SmoothingFunction()

    for idx, (refCode, preCode) in enumerate(
            zip(codecs.open(testFile, 'r', 'utf-8'), codecs.open(resultFile, 'r', 'utf-8'))):
        refer_tokens_for_bleu = tokenize_for_bleu_eval(refCode)
        pred_tokens_for_bleu = tokenize_for_bleu_eval(preCode)
        pred_tokens_for_bleu = process_class_names(pred_tokens_for_bleu)

        # try:
        ngram_weights = [0.25] * min(4, len(refer_tokens_for_bleu))
        bleu_score = sentence_bleu([refer_tokens_for_bleu], pred_tokens_for_bleu,
                                   weights=ngram_weights, smoothing_function=sm.method3)
        cum_bleu += bleu_score
    cum_blue = cum_bleu / 1805
    # print(cum_blue)
    return cum_blue


if __name__ == '__main__':
    acc = []
    bleu4 = []
    for i in range(10):
        testFile = 'testFile.txt'
        resultFile = 'output' + str(i+1) + '.hyp'
        a = cal_acc(testFile, resultFile)
        b = cal_bleu(testFile, resultFile)
        print('file', i+1)
        acc.append(a)
        bleu4.append(b)

    print(acc)
    print(bleu4)
